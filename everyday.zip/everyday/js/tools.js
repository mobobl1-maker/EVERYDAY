/* EVERYDAY — lógica pura de las herramientas (sin DOM, testeable en Node). */
(function (root) {
  'use strict';

  class InputError extends Error {}

  const num = (v) => {
    if (v === undefined || v === null || String(v).trim() === '') return null;
    const n = Number(String(v).replace(',', '.'));
    return Number.isFinite(n) ? n : null;
  };
  const need = (...vals) => {
    if (vals.some((v) => v === null || v === undefined)) throw new InputError('invalid');
  };
  const dayMs = 864e5;
  const parseDay = (s) => {
    if (!s || !/^\d{4}-\d{2}-\d{2}$/.test(s)) throw new InputError('invalid');
    const t = Date.parse(s + 'T00:00:00Z');
    if (Number.isNaN(t)) throw new InputError('invalid');
    return t;
  };

  /* Offset (ms) de una zona IANA en un instante dado. */
  function tzOffset(instantMs, tz) {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    }).formatToParts(new Date(instantMs));
    const g = (type) => Number(parts.find((p) => p.type === type).value);
    const asUTC = Date.UTC(g('year'), g('month') - 1, g('day'), g('hour'), g('minute'), g('second'));
    return asUTC - Math.floor(instantMs / 1000) * 1000;
  }

  const UNITS = {
    length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, ft: 0.3048, in: 0.0254 },
    weight: { kg: 1, g: 0.001, lb: 0.45359237, oz: 0.028349523125 },
    temperature: { c: 'c', f: 'f', k: 'k' },
  };

  const TOOLS = {
    percentage: {
      run({ pct, base }) {
        const p = num(pct), b = num(base); need(p, b);
        return { value: (b * p) / 100 };
      },
    },

    discount: {
      run({ price, pct }) {
        const p = num(price), d = num(pct); need(p, d);
        if (p < 0 || d < 0 || d > 100) throw new InputError('invalid');
        const saved = (p * d) / 100;
        return { value: p - saved, saved };
      },
    },

    age: {
      run({ birth }, now = new Date()) {
        const b = parseDay(birth);
        const bd = new Date(b);
        const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        if (b > today.getTime()) throw new InputError('future');
        let years = today.getUTCFullYear() - bd.getUTCFullYear();
        let months = today.getUTCMonth() - bd.getUTCMonth();
        if (today.getUTCDate() < bd.getUTCDate()) months -= 1;
        if (months < 0) { years -= 1; months += 12; }
        const days = Math.floor((today - b) / dayMs);
        let next = Date.UTC(today.getUTCFullYear(), bd.getUTCMonth(), bd.getUTCDate());
        if (next < today.getTime()) next = Date.UTC(today.getUTCFullYear() + 1, bd.getUTCMonth(), bd.getUTCDate());
        return { years, months, days, daysToBirthday: Math.round((next - today) / dayMs) };
      },
    },

    dates: {
      run({ start, end }) {
        const s = parseDay(start), e = parseDay(end);
        const days = Math.round((e - s) / dayMs);
        return { days, weeks: Math.floor(Math.abs(days) / 7), remainderDays: Math.abs(days) % 7 };
      },
    },

    tip: {
      run({ bill, pct, people }) {
        const b = num(bill), p = num(pct), n = num(people ?? 1);
        need(b, p, n);
        if (b < 0 || p < 0 || n < 1 || !Number.isInteger(n)) throw new InputError('invalid');
        const tip = (b * p) / 100;
        const total = b + tip;
        return { tip, total, perPerson: total / n };
      },
    },

    margin: {
      run({ cost, price }) {
        const c = num(cost), p = num(price); need(c, p);
        if (c < 0 || p <= 0) throw new InputError('invalid');
        const profit = p - c;
        return { profit, margin: (profit / p) * 100, markup: c > 0 ? (profit / c) * 100 : null };
      },
    },

    units: {
      run({ value, cat, from, to }) {
        const v = num(value); need(v);
        const table = UNITS[cat];
        if (!table || !table[from] || !table[to]) throw new InputError('invalid');
        if (cat === 'temperature') {
          let c = from === 'c' ? v : from === 'f' ? (v - 32) * 5 / 9 : v - 273.15;
          const out = to === 'c' ? c : to === 'f' ? c * 9 / 5 + 32 : c + 273.15;
          return { value: out };
        }
        return { value: (v * table[from]) / table[to] };
      },
    },

    timezone: {
      run({ date, time, from, to }) {
        const d = parseDay(date);
        const m = /^(\d{2}):(\d{2})$/.exec(time || '');
        if (!m) throw new InputError('invalid');
        const h = Number(m[1]), mi = Number(m[2]);
        if (h > 23 || mi > 59) throw new InputError('invalid');
        const guess = d + (h * 60 + mi) * 60000;
        // Dos pasadas para cubrir cambios de horario de verano.
        let instant = guess - tzOffset(guess, from);
        instant = guess - tzOffset(instant, from);
        const fmt = new Intl.DateTimeFormat('en-GB', {
          timeZone: to, dateStyle: 'medium', timeStyle: 'short',
        });
        return { value: fmt.format(new Date(instant)), instant };
      },
    },

    grades: {
      run(rows) {
        let sum = 0, wsum = 0, used = 0;
        for (const [g, w] of rows) {
          const gv = num(g), wv = num(w);
          if (gv === null && wv === null) continue;
          need(gv, wv);
          if (gv < 0 || gv > 10 || wv <= 0) throw new InputError('invalid');
          sum += gv * wv; wsum += wv; used++;
        }
        if (used === 0) throw new InputError('invalid');
        return { value: sum / wsum, used };
      },
    },

    decision: {
      run({ options }, rand = Math.random) {
        const list = String(options || '').split(/[,\n]/).map((s) => s.trim()).filter(Boolean);
        if (list.length < 2) throw new InputError('invalid');
        return { value: list[Math.floor(rand() * list.length)], count: list.length };
      },
    },
  };

  const api = { TOOLS, InputError, tzOffset, UNITS, num };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.EVERYDAY_TOOLS = api;
})(typeof window !== 'undefined' ? window : globalThis);
