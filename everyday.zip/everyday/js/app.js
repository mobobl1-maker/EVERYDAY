/* EVERYDAY — interfaz. Lógica de cálculo en tools.js. */
(function () {
  'use strict';
  const { TOOLS, InputError } = window.EVERYDAY_TOOLS;
  const $ = (s, el = document) => el.querySelector(s);
  const store = {
    get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* almacenamiento no disponible */ } },
  };

  /* ---------- Idiomas: solo se ofrecen los que tienen traducción completa. ---------- */
  const LANGS = { en: 'English', es: 'Español' };

  const S = {
    en: {
      appName: 'EVERYDAY', tagline: 'Useful tools for everyone. Solve it in seconds.',
      tools: 'Tools', trending: 'Trending now', trendingHint: 'Most used on this device so far.',
      recent: 'Recently used', favorites: 'Favorites', noFav: 'Star a tool to see it here.', noRecent: 'Nothing used yet.',
      calc: 'Calculate', result: 'Result', copy: 'Copy result', copied: 'Copied', share: 'Share on WhatsApp',
      fav: 'Favorite', unfav: 'Unfavorite', back: '← All tools', invalid: 'Please check the values you entered.',
      future: 'The date cannot be in the future.', reset: 'Reset', start: 'Start', pause: 'Pause', resume: 'Resume',
      focus: 'Focus', rest: 'Break', sessions: 'Sessions completed', notFound: 'This tool does not exist.',
      cat: { calc: 'Calculators & utilities', daily: 'Everyday life', students: 'Students', business: 'Business' },
      footerHome: 'Home', footerAbout: 'About', footerPrivacy: 'Privacy',
      aboutTitle: 'About EVERYDAY', aboutText: 'EVERYDAY is a collection of free, practical tools. Calculations run in your browser; nothing you enter is sent to a server.',
      privacyTitle: 'Privacy', privacyText: 'Favorites, history and preferences are stored only on this device (localStorage). The tools do not send your inputs anywhere. This page is a draft and has not been reviewed by a lawyer.',
      unitsFrom: 'From', unitsTo: 'To', value: 'Value', copyDone: 'Copied to clipboard',
      lbl: {
        pct: 'Percent (%)', base: 'Of this amount', price: 'Price', discount: 'Discount (%)', birth: 'Date of birth',
        start: 'Start date', end: 'End date', bill: 'Bill amount', tip: 'Tip (%)', people: 'People',
        cost: 'Cost', sell: 'Selling price', unitCat: 'Category', date: 'Date', time: 'Time (24 h)', fromZ: 'From time zone', toZ: 'To time zone',
        opt: 'Options (comma or new line)', g: 'Grade (0–10)', w: 'Weight',
      },
      t: {
        percentage: 'Percentage calculator', discount: 'Discount calculator', age: 'Age calculator', dates: 'Date difference',
        tip: 'Tip calculator', margin: 'Profit margin calculator', units: 'Unit converter', timezone: 'Time zone converter',
        worldclock: 'World clock', pomodoro: 'Pomodoro timer', grades: 'Grade calculator', decision: 'Random decision picker',
      },
      d: {
        percentage: 'What is X% of a number?', discount: 'Final price and how much you save.',
        age: 'Exact age in years, months and days.', dates: 'Days and weeks between two dates.',
        tip: 'Tip, total and split per person.', margin: 'Profit, margin and markup.',
        units: 'Length, weight and temperature.', timezone: 'Convert a time between zones.',
        worldclock: 'The current time in major cities.', pomodoro: '25 minutes focus, 5 minutes break.',
        grades: 'Weighted average of your grades.', decision: 'Let chance decide between options.',
      },
      res: {
        pct: 'Result', saved: 'You save', final: 'Final price', years: 'Years', months: 'Months', days: 'Days',
        daysToBirthday: 'Days until next birthday', totalDays: 'Total days', weeks: 'Full weeks',
        tip: 'Tip', total: 'Total', perPerson: 'Per person', profit: 'Profit', margin: 'Margin', markup: 'Markup',
        converted: 'Converted', utc: 'UTC', used: 'Grades used', pick: 'Chosen', options: 'Options',
      },
    },
    es: {
      appName: 'EVERYDAY', tagline: 'Herramientas útiles para todos. Resuélvelo en segundos.',
      tools: 'Herramientas', trending: 'Tendencias', trendingHint: 'Las más usadas hasta ahora en este dispositivo.',
      recent: 'Usadas recientemente', favorites: 'Favoritos', noFav: 'Marca una herramienta con la estrella para verla aquí.', noRecent: 'Aún no has usado ninguna.',
      calc: 'Calcular', result: 'Resultado', copy: 'Copiar resultado', copied: 'Copiado', share: 'Compartir por WhatsApp',
      fav: 'Añadir a favoritos', unfav: 'Quitar de favoritos', back: '← Todas las herramientas', invalid: 'Revisa los valores introducidos.',
      future: 'La fecha no puede estar en el futuro.', reset: 'Reiniciar', start: 'Iniciar', pause: 'Pausar', resume: 'Reanudar',
      focus: 'Concentración', rest: 'Descanso', sessions: 'Sesiones completadas', notFound: 'Esta herramienta no existe.',
      cat: { calc: 'Calculadoras y utilidades', daily: 'Vida cotidiana', students: 'Estudiantes', business: 'Empresas' },
      footerHome: 'Inicio', footerAbout: 'Acerca de', footerPrivacy: 'Privacidad',
      aboutTitle: 'Acerca de EVERYDAY', aboutText: 'EVERYDAY es un conjunto de herramientas gratuitas y prácticas. Los cálculos se realizan en tu navegador; lo que introduces no se envía a ningún servidor.',
      privacyTitle: 'Privacidad', privacyText: 'Los favoritos, el historial y las preferencias se guardan solo en este dispositivo (localStorage). Las herramientas no envían tus datos a ningún sitio. Esta página es un borrador y no ha sido revisada por un abogado.',
      unitsFrom: 'De', unitsTo: 'A', value: 'Valor', copyDone: 'Copiado al portapapeles',
      lbl: {
        pct: 'Porcentaje (%)', base: 'Sobre esta cantidad', price: 'Precio', discount: 'Descuento (%)', birth: 'Fecha de nacimiento',
        start: 'Fecha de inicio', end: 'Fecha de fin', bill: 'Importe de la cuenta', tip: 'Propina (%)', people: 'Personas',
        cost: 'Coste', sell: 'Precio de venta', unitCat: 'Categoría', date: 'Fecha', time: 'Hora (24 h)', fromZ: 'Zona horaria de origen', toZ: 'Zona horaria de destino',
        opt: 'Opciones (separadas por coma o salto de línea)', g: 'Nota (0–10)', w: 'Peso',
      },
      t: {
        percentage: 'Calculadora de porcentajes', discount: 'Calculadora de descuentos', age: 'Calculadora de edad', dates: 'Diferencia entre fechas',
        tip: 'Calculadora de propinas', margin: 'Calculadora de margen de beneficio', units: 'Conversor de unidades', timezone: 'Conversor de zonas horarias',
        worldclock: 'Reloj mundial', pomodoro: 'Temporizador Pomodoro', grades: 'Calculadora de notas', decision: 'Selector aleatorio de decisiones',
      },
      d: {
        percentage: '¿Cuánto es X% de un número?', discount: 'Precio final y cuánto ahorras.',
        age: 'Edad exacta en años, meses y días.', dates: 'Días y semanas entre dos fechas.',
        tip: 'Propina, total y reparto por persona.', margin: 'Beneficio, margen y markup.',
        units: 'Longitud, peso y temperatura.', timezone: 'Convierte una hora entre zonas.',
        worldclock: 'La hora actual en las principales ciudades.', pomodoro: '25 minutos de concentración, 5 de descanso.',
        grades: 'Media ponderada de tus notas.', decision: 'Deja que el azar decida entre opciones.',
      },
      res: {
        pct: 'Resultado', saved: 'Ahorras', final: 'Precio final', years: 'Años', months: 'Meses', days: 'Días',
        daysToBirthday: 'Días hasta tu próximo cumpleaños', totalDays: 'Días totales', weeks: 'Semanas completas',
        tip: 'Propina', total: 'Total', perPerson: 'Por persona', profit: 'Beneficio', margin: 'Margen', markup: 'Markup',
        converted: 'Convertido', utc: 'UTC', used: 'Notas usadas', pick: 'Elegido', options: 'Opciones',
      },
    },
  };

  const UNIT_OPTS = {
    en: { length: ['m', 'km', 'cm', 'mm', 'mi', 'ft', 'in'], weight: ['kg', 'g', 'lb', 'oz'], temperature: ['c', 'f', 'k'] },
    es: { length: ['m', 'km', 'cm', 'mm', 'mi', 'ft', 'in'], weight: ['kg', 'g', 'lb', 'oz'], temperature: ['c', 'f', 'k'] },
  };
  const ZONES = ['Europe/Madrid', 'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Los_Angeles',
    'America/Mexico_City', 'America/Sao_Paulo', 'Africa/Lagos', 'Asia/Dubai', 'Asia/Kolkata', 'Asia/Shanghai', 'Asia/Tokyo', 'Australia/Sydney', 'UTC'];

  /* Definición de herramientas: campos y orden. */
  const TOOL_META = {
    percentage: { cat: 'calc', fields: [['pct', 'number'], ['base', 'number']] },
    discount: { cat: 'calc', fields: [['price', 'number'], ['discount', 'number']] },
    age: { cat: 'calc', fields: [['birth', 'date']] },
    dates: { cat: 'calc', fields: [['start', 'date'], ['end', 'date']] },
    units: { cat: 'calc', fields: [['value', 'number'], ['unitCat', 'unitcat'], ['from', 'unit'], ['to', 'unit']] },
    timezone: { cat: 'calc', fields: [['date', 'date'], ['time', 'time'], ['fromZ', 'zone'], ['toZ', 'zone']] },
    worldclock: { cat: 'calc', special: true },
    tip: { cat: 'daily', fields: [['bill', 'number'], ['tip', 'number'], ['people', 'number']] },
    pomodoro: { cat: 'students', special: true },
    grades: { cat: 'students', special: true },
    decision: { cat: 'daily', fields: [['opt', 'text']] },
    margin: { cat: 'business', fields: [['cost', 'number'], ['sell', 'number']] },
  };

  let lang = 'en';
  const t = (k) => S[lang][k] ?? S.en[k] ?? k;
  const fmt = (n, digits = 2) => Number.isFinite(n) ? new Intl.NumberFormat(lang, { maximumFractionDigits: digits }).format(n) : '—';
  const fmtDate = (ms) => new Intl.DateTimeFormat(lang, { dateStyle: 'medium', timeStyle: 'short', timeZone: 'UTC' }).format(new Date(ms));

  /* ---------- Idioma, tema, preferencias ---------- */
  function detectLang() {
    const saved = store.get('ed_lang', null);
    if (saved && S[saved]) return saved;
    return (navigator.language || 'en').toLowerCase().startsWith('es') ? 'es' : 'en';
  }
  function applyLang(l) {
    lang = S[l] ? l : 'en';
    document.documentElement.lang = lang;
    document.documentElement.dir = 'ltr';
    document.title = `${t('appName')} — ${t('tagline')}`;
    $('#lang').value = lang;
    $('#app').setAttribute('aria-label', t('appName'));
    document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
    document.querySelectorAll('.footer a[href="#/"]').forEach((el) => el.textContent = t('footerHome'));
    store.set('ed_lang', lang);
  }
  function applyTheme(mode) {
    document.documentElement.dataset.theme = mode;
    store.set('ed_theme', mode);
  }
  function toast(msg) {
    let el = $('.toast');
    if (!el) { el = document.createElement('div'); el.className = 'toast'; el.setAttribute('role', 'status'); document.body.appendChild(el); }
    el.textContent = msg; el.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => el.classList.remove('show'), 1800);
  }

  /* ---------- Uso, historial, favoritos (solo en este dispositivo) ---------- */
  const usage = () => store.get('ed_usage', {});
  const favs = () => store.get('ed_fav', []);
  function trackOpen(id) {
    const u = usage(); u[id] = (u[id] || 0) + 1; store.set('ed_usage', u);
    const h = store.get('ed_hist', []).filter((x) => x.id !== id);
    h.unshift({ id, at: Date.now() }); store.set('ed_hist', h.slice(0, 20));
  }
  function toggleFav(id) {
    const f = favs(); const i = f.indexOf(id);
    if (i >= 0) f.splice(i, 1); else f.push(id);
    store.set('ed_fav', f); return i < 0;
  }

  /* ---------- Vistas ---------- */
  let timers = [];
  const clearTimers = () => { timers.forEach((id) => { clearInterval(id); clearTimeout(id); }); timers = []; };
  const app = () => $('#app');
  const link = (id) => `#/tool/${id}`;

  function toolCard(id) {
    return `<a class="card" href="${link(id)}"><h3>${t('t')[id]}</h3><p>${t('d')[id]}</p></a>`;
  }

  function viewHome() {
    const u = usage();
    const trending = Object.keys(TOOL_META).filter((id) => u[id]).sort((a, b) => u[b] - u[a]).slice(0, 5);
    const cats = ['calc', 'daily', 'students', 'business'];
    const recent = store.get('ed_hist', []).map((h) => h.id).filter((id) => TOOL_META[id]).slice(0, 5);
    const f = favs();
    app().innerHTML = `
      <h1>${t('tagline')}</h1>
      <h2>${t('trending')}</h2>
      ${trending.length ? `<p class="lead" style="font-size:14px">${t('trendingHint')}</p><div class="grid">${trending.map(toolCard).join('')}</div>` : `<p class="empty">${t('noRecent')}</p>`}
      <h2>${t('favorites')}</h2>
      ${f.length ? `<div class="grid">${f.map(toolCard).join('')}</div>` : `<p class="empty">${t('noFav')}</p>`}
      <h2>${t('recent')}</h2>
      ${recent.length ? `<div class="grid">${recent.map(toolCard).join('')}</div>` : `<p class="empty">${t('noRecent')}</p>`}
      ${cats.map((c) => `<h2>${t('cat')[c]}</h2><div class="grid">${Object.keys(TOOL_META).filter((id) => TOOL_META[id].cat === c).map(toolCard).join('')}</div>`).join('')}`;
  }

  function fieldHTML(id, [key, type]) {
    const label = t('lbl')[key] ?? key;
    if (type === 'number') return `<label>${label}<input name="${key}" type="text" inputmode="decimal" autocomplete="off"></label>`;
    if (type === 'date') return `<label>${label}<input name="${key}" type="date"></label>`;
    if (type === 'time') return `<label>${label}<input name="${key}" type="time" value="${new Date().toTimeString().slice(0, 5)}"></label>`;
    if (type === 'text') return `<label style="grid-column:1/-1">${label}<textarea class="field" name="${key}"></textarea></label>`;
    if (type === 'zone') return `<label>${label}<select class="field" name="${key}">${ZONES.map((z) => `<option ${z === (key === 'fromZ' ? 'Europe/Madrid' : 'UTC') ? 'selected' : ''}>${z}</option>`).join('')}</select></label>`;
    if (type === 'unitcat') return `<label>${label}<select class="field" name="unitCat">${Object.keys(UNIT_OPTS[lang] ?? UNIT_OPTS.en).map((c) => `<option value="${c}">${t('cat')[c] ?? c}</option>`).join('')}</select></label>`;
    if (type === 'unit') return `<label>${key === 'from' ? t('unitsFrom') : t('unitsTo')}<select class="field" name="${key}"></select></label>`;
    return '';
  }

  function viewTool(id) {
    if (!TOOL_META[id]) { app().innerHTML = `<p class="empty">${t('notFound')}</p>`; return; }
    trackOpen(id);
    const meta = TOOL_META[id];
    const f = favs().includes(id);
    app().innerHTML = `
      <a class="crumb" href="#/">${t('back')}</a>
      <div class="toolhead"><div><h1>${t('t')[id]}</h1><p class="lead">${t('d')[id]}</p></div>
        <button class="btn ghost" id="favbtn" aria-pressed="${f}">${f ? t('unfav') : t('fav')}</button></div>
      <div class="panel" style="margin-top:20px">
        ${meta.special ? '<div id="body"></div>' : `<form class="form" id="f" novalidate>${meta.fields.map((x) => fieldHTML(id, x)).join('')}</form>
        <div class="actions"><button class="btn" type="submit" form="f">${t('calc')}</button></div>
        <div id="out" aria-live="polite"></div>`}
      </div>`;
    $('#favbtn').onclick = (e) => { const on = toggleFav(id); e.target.textContent = on ? t('unfav') : t('fav'); e.target.setAttribute('aria-pressed', on); };
    if (id === 'units') wireUnits();
    if (meta.special) return SPECIAL[id]();
    $('#f').addEventListener('submit', (e) => { e.preventDefault(); run(id); });
    $('#f').addEventListener('input', () => { $('#out').innerHTML = ''; });
  }

  function wireUnits() {
    const cat = $('[name="unitCat"]'), from = $('[name="from"]'), to = $('[name="to"]');
    const fill = () => {
      const list = UNIT_OPTS[lang]?.[cat.value] ?? UNIT_OPTS.en[cat.value];
      const html = list.map((u) => `<option>${u}</option>`).join('');
      from.innerHTML = html; to.innerHTML = html; to.selectedIndex = Math.min(1, list.length - 1);
    };
    cat.addEventListener('change', fill); fill();
  }

  function readForm(form) {
    const o = {};
    new FormData(form).forEach((v, k) => { o[k] = String(v); });
    return o;
  }

  /* Dispatch de cálculos y render de resultados. */
  function run(id) {
    const form = $('#f'); const out = $('#out');
    const d = readForm(form);
    try {
      let r;
      if (id === 'tip') {
        r = TOOLS.tip.run({ bill: d.bill, pct: d.tip, people: d.people || '1' });
      } else if (id === 'percentage') {
        r = TOOLS.percentage.run({ pct: d.pct, base: d.base });
      } else if (id === 'discount') {
        r = TOOLS.discount.run({ price: d.price, pct: d.discount });
      } else if (id === 'age') {
        r = TOOLS.age.run({ birth: d.birth });
      } else if (id === 'dates') {
        r = TOOLS.dates.run({ start: d.start, end: d.end });
      } else if (id === 'margin') {
        r = TOOLS.margin.run({ cost: d.cost, price: d.sell });
      } else if (id === 'units') {
        r = TOOLS.units.run({ value: d.value, cat: d.unitCat, from: d.from, to: d.to });
      } else if (id === 'timezone') {
        r = TOOLS.timezone.run({ date: d.date, time: d.time, from: d.fromZ, to: d.toZ });
      } else if (id === 'decision') {
        r = TOOLS.decision.run({ options: d.opt });
      }
      out.innerHTML = RENDER[id](r, d);
    } catch (err) {
      const msg = err instanceof InputError && err.message === 'future' ? t('future') : t('invalid');
      out.innerHTML = `<p class="error" role="alert">${msg}</p>`;
    }
  }

  const RENDER = {
    percentage: (r) => block(fmt(r.value), [[t('res').pct, '']]),
    discount: (r) => block(fmt(r.value), [[t('res').final, fmt(r.value)], [t('res').saved, fmt(r.saved)]], true),
    age: (r) => block(`${r.years} ${t('res').years.toLowerCase()}`, [[t('res').months, r.months], [t('res').days, fmt(r.days, 0)], [t('res').daysToBirthday, fmt(r.daysToBirthday, 0)]], true),
    dates: (r) => block(`${fmt(Math.abs(r.days), 0)} ${t('res').days.toLowerCase()}`, [[t('res').weeks, fmt(r.weeks, 0)]], true),
    tip: (r) => block(fmt(r.total), [[t('res').tip, fmt(r.tip)], [t('res').perPerson, fmt(r.perPerson)]], true),
    margin: (r) => block(`${fmt(r.margin)}%`, [[t('res').profit, fmt(r.profit)], [t('res').markup, r.markup === null ? '—' : `${fmt(r.markup)}%`]], true),
    units: (r, d) => block(fmt(r.value, 6), [[t('res').converted, `${d.value} ${d.from} → ${d.to}`]]),
    timezone: (r) => block(r.value, [[t('res').utc, new Date(r.instant).toISOString().slice(0, 16).replace('T', ' ')]], true),
    decision: (r) => block(r.value, [[t('res').options, r.count]]),
  };

  function block(big, rows, withRows = false) {
    const id = 'res-' + Math.random().toString(36).slice(2, 7);
    const text = [big, ...rows.map(([k, v]) => `${k}: ${v}`)].join(' · ');
    const url = encodeURIComponent(`${text}\n${location.href}`);
    return `<div class="result" id="${id}">
      <div class="big">${big}</div>
      ${withRows && rows.length ? `<dl>${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>` : ''}
      <div class="actions">
        <button class="btn ghost" type="button" data-copy="${encodeURIComponent(text)}">${t('copy')}</button>
        <a class="btn ghost" target="_blank" rel="noopener" href="https://wa.me/?text=${url}">${t('share')}</a>
      </div></div>`;
  }

  /* Eventos delegados para copiar. */
  document.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-copy]');
    if (!b) return;
    try { await navigator.clipboard.writeText(decodeURIComponent(b.dataset.copy)); toast(t('copyDone')); }
    catch { toast(t('invalid')); }
  });

  /* Herramientas especiales: reloj mundial, Pomodoro, notas. */
  const SPECIAL = {
    worldclock() {
      const body = $('#body');
      const draw = () => {
        body.innerHTML = ZONES.map((z) => `<div class="clock-row"><span>${z.replace(/_/g, ' ')}</span><span>${new Intl.DateTimeFormat(lang, { timeZone: z, hour: '2-digit', minute: '2-digit', second: '2-digit', dateStyle: 'short' }).format(new Date())}</span></div>`).join('');
      };
      draw(); timers.push(setInterval(draw, 1000));
    },
    pomodoro() {
      const body = $('#body');
      const FOCUS = 25 * 60, REST = 5 * 60;
      let phase = 'focus', left = FOCUS, running = false, sessions = store.get('ed_pomo', 0);
      const render = () => {
        const m = String(Math.floor(left / 60)).padStart(2, '0'), s = String(left % 60).padStart(2, '0');
        body.innerHTML = `<p class="lead" style="text-align:center">${phase === 'focus' ? t('focus') : t('rest')}</p>
          <div class="timer" aria-live="off">${m}:${s}</div>
          <div class="actions" style="justify-content:center">
            <button class="btn" id="pm">${running ? t('pause') : (left === FOCUS || left === REST ? t('start') : t('resume'))}</button>
            <button class="btn ghost" id="pr">${t('reset')}</button></div>
          <p class="hint" style="text-align:center">${t('sessions')}: ${sessions}</p>`;
        $('#pm').onclick = toggle; $('#pr').onclick = reset;
      };
      let handle = null;
      const tick = () => {
        left -= 1;
        if (left <= 0) {
          if (phase === 'focus') { sessions++; store.set('ed_pomo', sessions); phase = 'rest'; left = REST; }
          else { phase = 'focus'; left = FOCUS; }
          try { if (navigator.vibrate) navigator.vibrate(200); } catch {}
        }
        render();
      };
      const toggle = () => {
        running = !running;
        if (running) handle = setInterval(tick, 1000), timers.push(handle);
        else clearInterval(handle);
        render();
      };
      const reset = () => { running = false; clearInterval(handle); phase = 'focus'; left = FOCUS; render(); };
      render();
    },
    grades() {
      const body = $('#body');
      body.innerHTML = `<form class="form" id="f" novalidate>
        ${[1, 2, 3].map((i) => `<label>${t('lbl').g} #${i}<input name="g${i}" inputmode="decimal"></label><label>${t('lbl').w} #${i}<input name="w${i}" inputmode="decimal"></label>`).join('')}
        </form><div class="actions"><button class="btn" type="submit" form="f">${t('calc')}</button></div><div id="out" aria-live="polite"></div>`;
      $('#f').addEventListener('submit', (e) => {
        e.preventDefault();
        const d = Object.fromEntries(new FormData(e.target));
        const out = $('#out');
        try {
          const r = TOOLS.grades.run([[d.g1, d.w1], [d.g2, d.w2], [d.g3, d.w3]]);
          out.innerHTML = block(fmt(r.value), [[t('res').used, r.used]], true);
        } catch { out.innerHTML = `<p class="error" role="alert">${t('invalid')}</p>`; }
      });
    },
  };

  /* ---------- Páginas estáticas ---------- */
  function viewStatic(kind) {
    const title = kind === 'about' ? t('aboutTitle') : t('privacyTitle');
    const text = kind === 'about' ? t('aboutText') : t('privacyText');
    app().innerHTML = `<a class="crumb" href="#/">${t('back')}</a><h1>${title}</h1><div class="prose"><p>${text}</p></div>`;
  }

  /* ---------- Enrutado ---------- */
  function route() {
    clearTimers();
    const h = location.hash.replace(/^#/, '') || '/';
    const [, a, b] = h.split('/');
    if (a === 'tool' && b) viewTool(b);
    else if (a === 'about') viewStatic('about');
    else if (a === 'privacy') viewStatic('privacy');
    else viewHome();
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  /* ---------- Arranque ---------- */
  function init() {
    const sel = $('#lang');
    sel.innerHTML = Object.entries(LANGS).map(([c, n]) => `<option value="${c}">${n}</option>`).join('');
    sel.addEventListener('change', () => { applyLang(sel.value); route(); });

    const theme = store.get('ed_theme', 'auto');
    applyTheme(theme);
    $('#theme').addEventListener('click', () => {
      const cur = document.documentElement.dataset.theme;
      applyTheme(cur === 'dark' ? 'light' : cur === 'light' ? 'auto' : 'dark');
    });

    applyLang(detectLang());
    window.addEventListener('hashchange', route);
    route();
  }
  document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', init) : init();
})();
