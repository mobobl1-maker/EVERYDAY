# EVERYDAY

Plataforma de herramientas digitales útiles (calculadoras, conversores, utilidades para estudiantes y empresas).

## Estado actual

Versión 0.1 — prototipo estático sin backend.

**Incluido y probado**
- Calculadora de porcentajes, descuentos, edad, diferencia de fechas, propinas, margen de beneficio.
- Conversor de unidades (longitud, peso, temperatura) y de zonas horarias.
- Reloj mundial, temporizador Pomodoro, calculadora de notas ponderadas, selector aleatorio de decisiones.
- Tema claro/oscuro/automático, favoritos e historial (solo en el dispositivo).
- Idiomas: inglés y español, con detección automática y selector manual.
- Pruebas de la lógica de cálculo: `node test/tools.test.js` (22 pruebas).

**Pendiente** (ver sección “Próximos pasos”)

## Ejecutar en local

No requiere instalación. Sirve la carpeta con cualquier servidor estático:

```bash
npx serve .          # o: python3 -m http.server 8080
```

Abre `http://localhost:8080`.

Pruebas: `node test/tools.test.js` (requiere Node 18+).

## Estructura

```
index.html        Punto de entrada y metaetiquetas básicas
css/styles.css    Sistema visual (variables de tema, responsive, reduced-motion)
js/tools.js       Lógica pura de las herramientas (sin DOM, testeable)
js/app.js         Interfaz, rutas, idiomas, favoritos e historial
test/             Pruebas de la lógica
```

## Próximos pasos

- Conversor de monedas: requiere un proveedor de tipos de cambio y una clave de API que debe mantenerse en el servidor.
- Idiomas restantes (catalán, francés, alemán, etc.): se añadirán solo con traducciones revisadas por hablantes nativos; no se usan traducciones automáticas.
- Cuentas, sincronización, suscripciones (Stripe), panel de administración, estadísticas globales de uso: requieren backend y base de datos.
- Páginas por herramienta indexables (SEO), sitemap y hreflang: requieren generación en build o servidor.
- Tarjetas descargables para compartir en imagen.
- Textos legales: son borradores y deben revisarlos abogados en cada mercado.

## Configuración que necesitas hacer tú

- Dominio y hosting.
- Cuenta de Stripe (cuando se implemente Premium) y claves de API en variables de entorno del servidor.
- Credenciales de Google OAuth (cuando se implemente el inicio de sesión con Google).
- Proveedor de tipos de cambio para el conversor de monedas.
