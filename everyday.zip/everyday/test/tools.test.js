const assert = require('assert');
const { TOOLS, InputError, tzOffset } = require('../js/tools.js');
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) < eps, `${a} != ${b}`);
const throwsInvalid = (fn) => assert.throws(fn, InputError);
let n = 0; const t = (name, f) => { f(); n++; console.log('ok -', name); };

t('percentage 15% de 200 = 30', () => near(TOOLS.percentage.run({ pct: '15', base: '200' }).value, 30));
t('percentage admite coma decimal', () => near(TOOLS.percentage.run({ pct: '12,5', base: '80' }).value, 10));
t('percentage rechaza vacío', () => throwsInvalid(() => TOOLS.percentage.run({ pct: '', base: '5' })));
t('discount 20% sobre 50 = 40, ahorro 10', () => {
  const r = TOOLS.discount.run({ price: '50', pct: '20' }); near(r.value, 40); near(r.saved, 10);
});
t('discount rechaza >100%', () => throwsInvalid(() => TOOLS.discount.run({ price: '50', pct: '120' })));
t('age: nacido 2000-05-10, hoy 2026-11-18 => 26 años', () => {
  const r = TOOLS.age.run({ birth: '2000-05-10' }, new Date('2026-11-18T12:00:00Z'));
  assert.strictEqual(r.years, 26); assert.strictEqual(r.months, 6);
  assert.strictEqual(r.daysToBirthday, 173);
});
t('age: fecha futura rechazada', () => throwsInvalid(() => TOOLS.age.run({ birth: '2030-01-01' }, new Date('2026-11-18T12:00:00Z'))));
t('dates: 2026-01-01 -> 2026-03-01 = 59 días', () => assert.strictEqual(TOOLS.dates.run({ start: '2026-01-01', end: '2026-03-01' }).days, 59));
t('tip: 10% de 80 entre 4 = total 88, 22 p.p.', () => {
  const r = TOOLS.tip.run({ bill: '80', pct: '10', people: '4' }); near(r.total, 88); near(r.perPerson, 22);
});
t('tip: personas no entero rechazado', () => throwsInvalid(() => TOOLS.tip.run({ bill: '80', pct: '10', people: '2.5' })));
t('margin: coste 60, precio 100 => margen 40%, markup 66.67%', () => {
  const r = TOOLS.margin.run({ cost: '60', price: '100' }); near(r.margin, 40); near(r.markup, 66.6666667, 1e-5);
});
t('units: 5 km = 5000 m', () => near(TOOLS.units.run({ value: '5', cat: 'length', from: 'km', to: 'm' }).value, 5000));
t('units: 1 mi = 1.609344 km', () => near(TOOLS.units.run({ value: '1', cat: 'length', from: 'mi', to: 'km' }).value, 1.609344));
t('units: 100 °C = 212 °F', () => near(TOOLS.units.run({ value: '100', cat: 'temperature', from: 'c', to: 'f' }).value, 212));
t('units: unidad inválida rechazada', () => throwsInvalid(() => TOOLS.units.run({ value: '1', cat: 'length', from: 'kg', to: 'm' })));
t('timezone: 10:00 Madrid (invierno) = 09:00 Londres', () => {
  const r = TOOLS.timezone.run({ date: '2026-01-15', time: '10:00', from: 'Europe/Madrid', to: 'Europe/London' });
  assert.ok(r.value.includes('09:00'), r.value);
});
t('timezone: 10:00 Madrid (verano) = 08:00 UTC', () => {
  const r = TOOLS.timezone.run({ date: '2026-07-15', time: '10:00', from: 'Europe/Madrid', to: 'UTC' });
  assert.ok(r.value.includes('08:00'), r.value);
});
t('tzOffset Tokio = +9h', () => near(tzOffset(Date.UTC(2026, 0, 1), 'Asia/Tokyo'), 9 * 3600e3));
t('grades: ponderada 8 (peso 1) y 6 (peso 3) = 6.5', () => {
  const r = TOOLS.grades.run([['8', '1'], ['6', '3'], ['', '']]); near(r.value, 6.5); assert.strictEqual(r.used, 2);
});
t('grades: nota fuera de 0-10 rechazada', () => throwsInvalid(() => TOOLS.grades.run([['11', '1']])));
t('decision: elige una opción válida', () => {
  const r = TOOLS.decision.run({ options: 'pizza, sushi\nensalada' }, () => 0.99);
  assert.strictEqual(r.value, 'ensalada'); assert.strictEqual(r.count, 3);
});
t('decision: menos de 2 opciones rechazado', () => throwsInvalid(() => TOOLS.decision.run({ options: 'solo' })));
console.log(`\n${n} pruebas superadas`);
